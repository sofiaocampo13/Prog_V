require('dotenv').config();
const express = require('express');
const app = express();
const cors = require('cors');

const rutasEstudiante = require('./rutas/rutasEstudiante');
const rutasProfesor = require('./rutas/rutasProfesor');
const rutasMateria = require('./rutas/rutasMateria');
const rutasInscripcion = require('./rutas/rutasInscripcion');

app.use(express.json());
app.use(cors());

app.use('/api/estudiantes', rutasEstudiante);
app.use('/api/profesores', rutasProfesor);
app.use('/api/materias', rutasMateria);
app.use('/api/inscripciones', rutasInscripcion);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});


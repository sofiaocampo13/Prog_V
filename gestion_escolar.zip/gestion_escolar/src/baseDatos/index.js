require('dotenv').config(); //Inicializo las variables de entorno

const { Sequelize, DataTypes } = require('sequelize'); //Importo Sequelize y DataTypes

//Llamo cada uno de los modelos creados
const defineEstudiante = require('../modelos/estudiante');
const defineProfesor = require('../modelos/profesor');
const defineMateria = require('../modelos/materia');
const defineInscripcion = require('../modelos/inscripcion');

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: process.env.DB_DIALECT
  }
);

const Estudiante = defineEstudiante(sequelize, DataTypes);
const Profesor = defineProfesor(sequelize, DataTypes);
const Materia = defineMateria(sequelize, DataTypes);
const Inscripcion = defineInscripcion(sequelize, DataTypes);

//Un estudiante puede tener muchas inscripciones
Estudiante.hasMany(Inscripcion, { foreignKey: 'estudiante_id' });
Inscripcion.belongsTo(Estudiante, { foreignKey: 'estudiante_id' });

//Una materia puede tener muchas inscripciones
Materia.hasMany(Inscripcion, { foreignKey: 'materia_id' });
Inscripcion.belongsTo(Materia, { foreignKey: 'materia_id' });

//Un profesor puede tener muchas materias
Profesor.hasMany(Materia, { foreignKey: 'profesor_id' });  

//Cada materia tiene un único profesor
Materia.belongsTo(Profesor, { foreignKey: 'profesor_id' });

//Conexión con la base de datos
sequelize.authenticate()
  .then(() => console.log('Conectado a la base de datos.'))
  .catch(err => console.error('No se pudo conectar a la base de datos:', err));

//Sincronización de modelos
sequelize.sync({ alter: true, force: false })
  .then(() => console.log('Sincronización completada.'))
  .catch(err => console.error('Error en la sincronización:', err));

//Exporto los modelos
module.exports = {
  Estudiante,
  Profesor,
  Materia,
  Inscripcion,
  sequelize
};

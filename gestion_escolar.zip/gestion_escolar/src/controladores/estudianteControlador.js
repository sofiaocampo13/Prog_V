const Joi = require('joi');
const { Estudiante, Inscripcion, Materia } = require('../baseDatos/index');

//Validador
const validadorRegistro = Joi.object({
  id: Joi.string().min(4).max(10).required().messages({
    'string.base': 'El ID debe ser un texto.',
    'string.empty': 'El ID es obligatorio.',
    'string.min': 'El ID debe tener al menos {#limit} caracteres.',
    'string.max': 'El ID no puede tener más de {#limit} caracteres.',
    'any.required': 'El ID es un campo obligatorio.'
  }),
  nombre: Joi.string().min(2).max(50).required().messages({
    'string.base': 'El nombre debe ser un texto.',
    'string.empty': 'El nombre es obligatorio.',
    'string.min': 'El nombre debe tener al menos {#limit} caracteres.',
    'string.max': 'El nombre no puede tener más de {#limit} caracteres.',
    'any.required': 'El nombre es un campo obligatorio.'
  }),
  correo: Joi.string().email().required().messages({
    'string.base': 'El correo debe ser un texto.',
    'string.empty': 'El correo es obligatorio.',
    'string.email': 'El correo debe ser un correo electrónico válido.',
    'any.required': 'El correo es un campo obligatorio.'
  }),
  fecha_nacimiento: Joi.date().less('now').required().messages({
    'date.base': 'La fecha de nacimiento debe ser válida.',
    'date.less': 'La fecha debe ser anterior a hoy.',
    'string.empty': 'La fecha de nacimiento es obligatoria.',
    'any.required': 'La fecha de nacimiento es obligatoria.'
  })
});

//Métodos

//REGISTRAR
const registrarEstudiante = async (req, res) => {
  try {
    const { error } = validadorRegistro.validate(req.body, { abortEarly: false });
    if (error) {
      const mensajesErrores = error.details.map(detail => detail.message).join(' | ');
      return res.status(400).json({
        mensaje: 'Errores en la validación',
        resultado: {
          id: '',
          correo: '',
          nombre: '',
          fecha_nacimiento: '',
          erroresValidacion: mensajesErrores
        }
      });
    }

    const { id, correo, nombre, fecha_nacimiento } = req.body;

    const estudianteExistente = await Estudiante.findByPk(id);
    if (estudianteExistente) {
      return res.status(400).json({ mensaje: 'El estudiante ya existe', resultado: null });
    }

    const nuevoEstudiante = await Estudiante.create({ id, correo, nombre, fecha_nacimiento });

    res.status(201).json({
      mensaje: 'Estudiante creado',
      resultado: {
        id: nuevoEstudiante.id,
        correo: nuevoEstudiante.correo,
        nombre: nuevoEstudiante.nombre,
        fecha_nacimiento: nuevoEstudiante.fecha_nacimiento,
        erroresValidacion: ''
      }
    });

  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//LISTAR
const listarEstudiantes = async (_req, res) => {
  try {
    const estudiantes = await Estudiante.findAll();
    res.status(200).json({ mensaje: 'Estudiantes listados', resultado: estudiantes });
  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//ACTUALIZAR
const actualizarEstudiante = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, correo, fecha_nacimiento } = req.body;

    const estudiante = await Estudiante.findByPk(id);
    if (!estudiante) {
      return res.status(404).json({ mensaje: 'Estudiante no encontrado', resultado: null });
    }

    await Estudiante.update({ nombre, correo, fecha_nacimiento }, { where: { id } });

    res.status(200).json({ mensaje: 'Estudiante actualizado', resultado: { id, nombre, correo, fecha_nacimiento } });
  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//BORRAR
const borrarEstudiante = async (req, res) => {
  try {
    const { id } = req.params;

    const estudiante = await Estudiante.findByPk(id);
    if (!estudiante) {
      return res.status(404).json({ mensaje: 'Estudiante no encontrado', resultado: null });
    }

    await Estudiante.destroy({ where: { id } });

    res.status(200).json({ mensaje: 'Estudiante eliminado', resultado: id });
  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//INSCRIBIR ESTUDIANTE EN MATERIAS
const inscribirEstudiante = async (req, res) => {
    try {
      const { estudiante_id, materia_id } = req.body;
      
      const estudiante = await Estudiante.findByPk(estudiante_id);
      if (!estudiante) {
        return res.status(404).json({ mensaje: 'Estudiante no encontrado', resultado: null });
      }
      
      //Verifica si la materia existe
      const materia = await Materia.findByPk(materia_id);
      if (!materia) {
        return res.status(404).json({ mensaje: 'Materia no encontrada', resultado: null });
      }
  
      //Si el estudiante ya está inscrito en la materia
      const inscripcionExistente = await Inscripcion.findOne({
        where: {
          estudiante_id,
          materia_id
        }
      });
  
      if (inscripcionExistente) {
        return res.status(400).json({ mensaje: 'El estudiante ya está inscrito en esta materia', resultado: null });
      }
  
      //Si no, crear la inscripción
      const nuevaInscripcion = await Inscripcion.create({
        estudiante_id,
        materia_id,
        fecha_inscripcion: new Date()
      });
  
      res.status(201).json({
        mensaje: 'Estudiante inscrito en la materia',
        resultado: {
          estudiante_id: nuevaInscripcion.estudiante_id,
          materia_id: nuevaInscripcion.materia_id,
          fecha_inscripcion: nuevaInscripcion.fecha_inscripcion
        }
      });
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };

module.exports = {
  registrarEstudiante,
  listarEstudiantes,
  actualizarEstudiante,
  borrarEstudiante,
  inscribirEstudiante
};



const { Inscripcion, Estudiante, Materia } = require('../baseDatos/index');

//Métodos

//LISTAR
const listarInscripciones = async (_req, res) => {
  try {
    const inscripciones = await Inscripcion.findAll({
      include: [
        { model: Estudiante, attributes: ['id', 'nombre', 'correo'] },
        { model: Materia, attributes: ['id', 'nombre'] }
      ]
    });
    res.status(200).json({ mensaje: 'Inscripciones listadas', resultado: inscripciones });
  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//BORRAR
const eliminarInscripcion = async (req, res) => {
  try {
    const { estudiante_id, materia_id } = req.body;

    const inscripcion = await Inscripcion.findOne({
      where: { estudiante_id, materia_id }
    });

    if (!inscripcion) {
      return res.status(404).json({ mensaje: 'Inscripción no encontrada', resultado: null });
    }

    await inscripcion.destroy();

    res.status(200).json({
      mensaje: 'Inscripción eliminada correctamente',
      resultado: { estudiante_id, materia_id }
    });
  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//OBTENER INSCRIPCIONES POR MATERIA
const inscripcionesPorMateria = async (req, res) => {
  try {
    const { materia_id } = req.params;

    const inscripciones = await Inscripcion.findAll({
      where: { materia_id },
      include: [{ model: Estudiante, attributes: ['id', 'nombre'] }]
    });

    res.status(200).json({
      mensaje: `Estudiantes inscritos en la materia ${materia_id}`,
      resultado: inscripciones
    });
  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//OBTENER INSCRIPCIONES POR ESTUDIANTE
const inscripcionesPorEstudiante = async (req, res) => {
  try {
    const { estudiante_id } = req.params;

    const inscripciones = await Inscripcion.findAll({
      where: { estudiante_id },
      include: [{ model: Materia, attributes: ['id', 'nombre'] }]
    });

    res.status(200).json({
      mensaje: `Materias en las que está inscrito el estudiante ${estudiante_id}`,
      resultado: inscripciones
    });
  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

module.exports = {
  listarInscripciones,
  eliminarInscripcion,
  inscripcionesPorMateria,
  inscripcionesPorEstudiante
};

const Joi = require('joi');
const { Materia, Profesor } = require('../baseDatos/index');

//Validador
const validadorRegistro = Joi.object({
    nombre: Joi.string().min(2).max(50).required().messages({
      'string.base': 'El nombre debe ser un texto.',
      'string.empty': 'El nombre es obligatorio.',
      'string.min': 'El nombre debe tener al menos {#limit} caracteres.',
      'string.max': 'El nombre no puede tener más de {#limit} caracteres.',
      'any.required': 'El nombre es un campo obligatorio.'
    }),
  });

//Métodos

//REGISTRAR
const registrarMateria = async (req, res) => {
  const { nombre } = req.body;

  try {
    const materiaExistente = await Materia.findOne({ where: { nombre } });

    if (materiaExistente) {
      return res.status(400).json({ mensaje: 'La materia ya existe. Intenta con otro nombre.'
      });
    }

    const nuevaMateria = await Materia.create(req.body);

    res.status(201).json({
      mensaje: 'Materia registrada exitosamente',
      materia: nuevaMateria
    });
  } catch (error) {
    res.status(500).json({
      mensaje: 'Error al registrar la materia',
      error: error
    });
  }
};

//LISTAR
const listarMaterias = async (_req, res) => {
    try {
      const materias = await Materia.findAll({
        include: [{ model: Profesor, attributes: ['id', 'nombre', 'correo'] }]
      });
      res.status(200).json({ mensaje: 'Materias listadas', resultado: materias });
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };
  
// ACTUALIZAR
const actualizarMateria = async (req, res) => {
    try {
      const { id } = req.params;
      const { nombre, profesor_id } = req.body;
  
      const materia = await Materia.findByPk(id);
      if (!materia) {
        return res.status(404).json({ mensaje: 'Materia no encontrada', resultado: null });
      }
  
      //Si se busca con el id del profesor, verificamos que exista
      if (profesor_id) {
        const profesor = await Profesor.findByPk(profesor_id);
        if (!profesor) {
          return res.status(404).json({ mensaje: 'Profesor no encontrado', resultado: null });
        }
      }

      //Si existe y se puede modificar
      await materia.update({ nombre, profesor_id });
  
      res.status(200).json({
        mensaje: 'Materia actualizada',
        resultado: { id: materia.id, nombre, profesor_id }
      });
  
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };

//BORRAR
const borrarMateria = async (req, res) => {
    try {
      const { id } = req.params;
  
      const materia = await Materia.findByPk(id);
      if (!materia) {
        return res.status(404).json({ mensaje: 'Materia no encontrada', resultado: null });
      }
  
      await Materia.destroy({ where: { id } });
  
      res.status(200).json({ mensaje: 'Materia eliminada', resultado: id });
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };
  
  module.exports = {
    registrarMateria,
    listarMaterias,
    actualizarMateria,
    borrarMateria,
  };
  
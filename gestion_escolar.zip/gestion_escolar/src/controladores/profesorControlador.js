const Joi = require('joi');
const { Profesor, Materia} = require('../baseDatos/index');

//Validador
const validadorRegistro = Joi.object({
    id: Joi.string().min(4).max(10).required().messages({
        'string.base': 'El ID debe ser un texto.',
        'string.empty': 'El ID es obligatorio.',
        'string.min': 'El ID debe tener al menos {#limit} caracteres.',
        'string.max': 'El ID no puede tener más de {#limit} caracteres.',
        'any.required': 'El ID es un campo obligatorio.'
    }),
    nombre: Joi.string().min(2).max(50).required().messages({
        'string.base': 'El nombre debe ser un texto.',
        'string.empty': 'El nombre es obligatorio.',
        'string.min': 'El nombre debe tener al menos {#limit} caracteres.',
        'string.max': 'El nombre no puede tener más de {#limit} caracteres.',
        'any.required': 'El nombre es un campo obligatorio.'
    }),
    correo: Joi.string().email().required().messages({
        'string.base': 'El correo debe ser un texto.',
        'string.empty': 'El correo es obligatorio.',
        'string.email': 'El correo debe ser un correo electrónico válido.',
        'any.required': 'El correo es un campo obligatorio.'
    }),
    titulo: Joi.string().min(5).max(100).required().messages({
        'string.base': 'El título debe ser un texto.',
        'string.empty': 'El título es obligatorio.',
        'string.min': 'El título debe tener al menos {#limit} caracteres.',
        'string.max': 'El título no puede tener más de {#limit} caracteres.',
        'any.required': 'El título es un campo obligatorio.'
    })
})

//Métodos

//REGISTRAR
const registrarProfesor = async(req, res) => {
    try {
        const { error } = validadorRegistro.validate(req.body, { abortEarly: false });
        if (error) {
          const mensajesErrores = error.details.map(detail => detail.message).join(' | ');
          return res.status(400).json({
            mensaje: 'Errores en la validación',
            resultado: {
              id: '',
              nombre: '',
              correo: '',
              titulo: '',
              erroresValidacion: mensajesErrores
            }
          });
        }

        const { id, nombre, correo, titulo } = req.body;
        const profesorExistente = await Profesor.findByPk(id);

    if (profesorExistente) {
      return res.status(400).json({ mensaje: 'El profesor ya existe', resultado: null });
    }

    const nuevoProfesor = await Profesor.create({ id, nombre, correo, titulo });

    res.status(201).json({
      mensaje: 'Profesor creado',
      resultado: {
        id: nuevoProfesor.id,
        correo: nuevoProfesor.correo,
        nombre: nuevoProfesor.nombre,
        titulo: nuevoProfesor.titulo,
        erroresValidacion: ''
      }
    });

  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

//LISTAR
const listarProfesores = async (_req, res) => {
    try {
      const profesores = await Profesor.findAll();
      res.status(200).json({ mensaje: 'Profesores listados', resultado: profesores });
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };

//ACTUALIZAR
const actualizarProfesor = async (req, res) => {
    try {
      const { id } = req.params;
      const { nombre, correo, titulo } = req.body;
  
      const profesor = await Profesor.findByPk(id);
      if (!profesor) {
        return res.status(404).json({ mensaje: 'Profesor no encontrado', resultado: null });
      }
  
      await Profesor.update({ nombre, correo, titulo }, { where: { id } });
  
      res.status(200).json({ mensaje: 'Profesor actualizado', resultado: { id, nombre, correo, titulo } });
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };

//BORRAR
const borrarProfesor = async (req, res) => {
    try {
      const { id } = req.params;
  
      const profesor = await Profesor.findByPk(id);
      if (!profesor) {
        return res.status(404).json({ mensaje: 'Profesor no encontrado', resultado: null });
      }
  
      await Profesor.destroy({ where: { id } });
  
      res.status(200).json({ mensaje: 'Profesor eliminado', resultado: id });
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };

//ASIGNAR PROFESOR A UNA MATERIA
const asignarProfesorAMateria = async (req, res) => {
    try {
      const { profesor_id, materia_id } = req.body;

      //Si no se encuentra el profesor
      const profesor = await Profesor.findByPk(profesor_id);
      if (!profesor) {
        return res.status(404).json({ mensaje: 'Profesor no encontrado', resultado: null });
      }
  
      //Si no se encuentra la materia
      const materia = await Materia.findByPk(materia_id);
      if (!materia) {
        return res.status(404).json({ mensaje: 'Materia no encontrada', resultado: null });
      }
  
      //Asignamos al profesor la materia si se encuentran ambos
      await materia.update({ profesor_id });
  
      res.status(200).json({
        mensaje: 'Profesor asignado a la materia',
        resultado: {
          profesor_id: profesor.id,
          materia_id: materia.id
        }
      });
    } catch (error) {
      res.status(500).json({ mensaje: error.message, resultado: null });
    }
  };

//OBTENER MATERIAS DICTADAS POR UN PROFESOR
const obtenerMateriasPorProfesor = async (req, res) => {
  try {
    const { id } = req.params;

    const profesor = await Profesor.findByPk(id, {
      include: [
        {
          model: Materia, attributes: ['id', 'nombre']
        }
      ]
    });

    // Si no se encuentra el profesor
    if (!profesor) {
      return res.status(404).json({ mensaje: 'Profesor no encontrado', resultado: null });
    }

    //Si el profesor existe
    res.status(200).json({
      mensaje: `Materias dictadas por el profesor con ID ${id}`,
      resultado: profesor
    });

  } catch (error) {
    res.status(500).json({ mensaje: error.message, resultado: null });
  }
};

  
  module.exports = {
    registrarProfesor,
    listarProfesores,
    actualizarProfesor,
    borrarProfesor,
    asignarProfesorAMateria,
    obtenerMateriasPorProfesor
  };
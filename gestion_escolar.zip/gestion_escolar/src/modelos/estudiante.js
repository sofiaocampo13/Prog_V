const defineEstudiante = (sequelize, DataTypes) => {
  return sequelize.define('Estudiante', {
      id: {
          type: DataTypes.STRING,
          primaryKey: true,
          allowNull: false
      },
      nombre: {
          type: DataTypes.STRING,
          allowNull: false
      },
      correo: {
          type: DataTypes.STRING,
          allowNull: false,
          unique: 'correo'
      },
      fecha_nacimiento: {
          type: DataTypes.DATE,
          allowNull: false
      }
  }, {
      tableName: 'estudiante',
      timestamps: true
  });
};

module.exports = defineEstudiante;

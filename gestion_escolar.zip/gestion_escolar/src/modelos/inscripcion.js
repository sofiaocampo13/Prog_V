const defineInscripcion = (sequelize, DataTypes) => {
    return sequelize.define('Inscripcion', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        estudiante_id: {
            type: DataTypes.STRING,
            allowNull: false
        },
        materia_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        fecha_inscripcion: {
            type: DataTypes.DATE,
            allowNull: false
        }
    }, {
        tableName: 'inscripcion',
        timestamps: true
    });
};

module.exports = defineInscripcion;

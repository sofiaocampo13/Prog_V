const defineMateria = (sequelize, DataTypes) => {
    return sequelize.define('Materia', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        nombre: {
            type: DataTypes.STRING,
            allowNull: false
        },
        profesor_id: {
            type: DataTypes.STRING,
            allowNull: false
        }
    }, {
        tableName: 'materia',
        timestamps: true
    });
};

module.exports = defineMateria;
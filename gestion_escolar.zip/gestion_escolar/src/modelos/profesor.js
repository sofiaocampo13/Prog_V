const defineProfesor = (sequelize, DataTypes) => {
    return sequelize.define('Profesor', {
        id: {
            type: DataTypes.STRING,
            primaryKey: true,
            allowNull: false
        },
        nombre: {
            type: DataTypes.STRING,
            allowNull: false
        },
        correo: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: 'correo'
        },
        titulo: {
            type: DataTypes.STRING,
            allowNull: false
        }
    }, {
        tableName: 'profesor',
        timestamps: true
    });
};

module.exports = defineProfesor;
const express = require('express');
const enrutador = express.Router();
const estudianteControlador = require('../controladores/estudianteControlador');

enrutador.post('/registrar', estudianteControlador.registrarEstudiante); //Registrar un estudiante
enrutador.get('/listar', estudianteControlador.listarEstudiantes); //Listar estudiantes
enrutador.put('/actualizar/:id', estudianteControlador.actualizarEstudiante); //Actualizar un estudiante
enrutador.delete('/eliminar/:id', estudianteControlador.borrarEstudiante); //Borrar un estudiante
enrutador.post('/inscribir-estudiante', estudianteControlador.inscribirEstudiante); //Inscribir un estudiante en una materia

module.exports = enrutador;

const express = require('express');
const enrutador = express.Router();
const inscripcionControlador = require('../controladores/inscripcionControlador');

enrutador.get('/listar', inscripcionControlador.listarInscripciones); //Listar inscripciones
enrutador.delete('/eliminar', inscripcionControlador.eliminarInscripcion); //Eliminar inscripción
enrutador.get('/pormateria/:materia_id', inscripcionControlador.inscripcionesPorMateria); //Inscripciones por materia
enrutador.get('/porestudiante/:estudiante_id', inscripcionControlador.inscripcionesPorEstudiante); //Obtener materias inscritas de un estudiante

module.exports = enrutador;
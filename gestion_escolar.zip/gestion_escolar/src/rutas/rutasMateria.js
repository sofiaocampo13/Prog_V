const express = require('express');
const enrutador = express.Router();
const materiaControlador = require('../controladores/materiaControlador');

enrutador.post('/registrar', materiaControlador.registrarMateria); //Crear una materia
enrutador.get('/listar', materiaControlador.listarMaterias); //Listar materias
enrutador.put('/actualizar/:id', materiaControlador.actualizarMateria); //Actualizar una materia
enrutador.delete('/eliminar/:id', materiaControlador.borrarMateria); //Borrar una materia

module.exports = enrutador;
const express = require('express');
const enrutador = express.Router();
const profesorControlador = require('../controladores/profesorControlador');

enrutador.post('/registrar', profesorControlador.registrarProfesor); //Registrar un profesor
enrutador.get('/listar', profesorControlador.listarProfesores); //Listar profesores
enrutador.put('/actualizar/:id', profesorControlador.actualizarProfesor); //Actualizar un profesor
enrutador.delete('/borrar/:id', profesorControlador.borrarProfesor); //Borrar un profesor
enrutador.post('/asignar-profesor', profesorControlador.asignarProfesorAMateria); //Asignar un profesor a una materia
enrutador.get('/materias/:id', profesorControlador.obtenerMateriasPorProfesor); //Obtener materias dictadas por un profesor

module.exports = enrutador;